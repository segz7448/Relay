import { useCallback, useMemo, useState } from 'react';
import { View, Text, SectionList, Pressable, RefreshControl, StyleSheet } from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { type, space, useTheme } from '../../theme';
import CallRow from '../../components/CallRow';
import FilterChips from '../../components/FilterChips';
import NewCallSheet from '../../components/NewCallSheet';
import ActionSheet from '../../components/ActionSheet';
import { SkeletonList } from '../../components/Skeleton';
import { EmptyState, ErrorState } from '../../components/StateViews';
import { useToast } from '../../components/Toast';
import { useConfirm } from '../../components/ConfirmDialog';
import { hapticTap } from '../../utils/haptics';
import { fetchCalls, deleteCall, deleteCalls, clearHistory, randomCallableContact, CALL_FILTERS } from '../../callsApi';

function dayLabel(ts) {
  const d = new Date(ts);
  const today = new Date();
  const yest = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const sameDay = (a, b) => a.toDateString() === b.toDateString();
  if (sameDay(d, today)) return 'Today';
  if (sameDay(d, yest)) return 'Yesterday';
  return d.toLocaleDateString(undefined, { month: 'long', day: 'numeric' });
}

export default function CallsScreen() {
  const router = useRouter();
  const { colors } = useTheme();
  const styles = useMemo(() => getStyles(colors), [colors]);
  const toast = useToast();
  const confirm = useConfirm();

  const [filter, setFilter] = useState('recent');
  const [calls, setCalls] = useState([]);
  const [phase, setPhase] = useState('loading'); // 'loading' | 'ready' | 'error'
  const [refreshing, setRefreshing] = useState(false);
  const [editing, setEditing] = useState(false);
  const [selected, setSelected] = useState([]);
  const [sheetCall, setSheetCall] = useState(null);
  const [newCallOpen, setNewCallOpen] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await fetchCalls(filter);
      setCalls(data);
      setPhase('ready');
    } catch (e) {
      setPhase('error');
    }
  }, [filter]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function onRefresh() {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }

  async function retry() {
    setPhase('loading');
    await load();
  }

  const sections = useMemo(() => {
    const groups = new Map();
    for (const c of calls) {
      const label = dayLabel(c.at);
      if (!groups.has(label)) groups.set(label, []);
      groups.get(label).push(c);
    }
    return Array.from(groups.entries()).map(([title, data]) => ({ title, data }));
  }, [calls]);

  function toggleSelect(call) {
    setSelected((list) => (list.includes(call.id) ? list.filter((id) => id !== call.id) : [...list, call.id]));
  }

  function handleStartCall(contact, type) {
    router.push(`/call/${contact.id}?type=${type}`);
  }

  // No signaling backend exists to actually ring this device, so this is
  // the demo entry point for the incoming-call screen: long-press the
  // "+" to have a random callable contact "call" you.
  async function handleSimulateIncoming() {
    hapticTap();
    const contact = await randomCallableContact();
    if (!contact) return;
    const type = Math.random() < 0.35 ? 'video' : 'voice';
    router.push(`/call/${contact.id}/incoming?type=${type}`);
  }

  async function handleDelete(call) {
    try {
      await deleteCall(call.id);
      await load();
    } catch (e) {
      toast.error("Couldn't delete that call");
    }
  }

  async function handleDeleteSelected() {
    const count = selected.length;
    const ok = await confirm({
      title: 'Delete calls?',
      message: `Delete ${count} selected call${count === 1 ? '' : 's'}?`,
      confirmLabel: 'Delete',
      destructive: true,
      onConfirm: async () => {
        await deleteCalls(selected);
        setSelected([]);
        setEditing(false);
        await load();
      },
    });
    if (ok) toast.success(`${count} call${count === 1 ? '' : 's'} deleted`);
  }

  async function handleClearHistory() {
    const scope = CALL_FILTERS.find((f) => f.key === filter)?.label.toLowerCase() || 'recent';
    const ok = await confirm({
      title: 'Delete history?',
      message: `Delete all ${filter === 'recent' ? '' : scope + ' '}calls? This can't be undone.`,
      confirmLabel: 'Delete',
      destructive: true,
      onConfirm: async () => {
        await clearHistory(filter);
        await load();
      },
    });
    if (ok) toast.success('Call history cleared');
  }

  const sheetActions = sheetCall
    ? [
        { key: 'call', icon: 'call-outline', label: 'Call', onPress: () => handleStartCall(sheetCall.contact, 'voice') },
        { key: 'video', icon: 'videocam-outline', label: 'Video call', onPress: () => handleStartCall(sheetCall.contact, 'video') },
        { key: 'history', icon: 'time-outline', label: 'Call history', onPress: () => router.push(`/call/${sheetCall.contactId}/history`) },
        { key: 'delete', icon: 'trash-outline', label: 'Delete', destructive: true, onPress: () => handleDelete(sheetCall) },
      ]
    : [];

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <Pressable onPress={() => { hapticTap(); setEditing((v) => !v); setSelected([]); }} hitSlop={10}>
          <Text style={styles.headerAction}>{editing ? 'Done' : 'Edit'}</Text>
        </Pressable>
        <Text style={styles.title}>Calls</Text>
        <View style={{ flexDirection: 'row', gap: space.md }}>
          {calls.length > 0 && !editing ? (
            <Pressable onPress={handleClearHistory} hitSlop={10}>
              <Ionicons name="trash-outline" size={20} color={colors.danger} />
            </Pressable>
          ) : null}
          <Pressable
            onPress={() => { hapticTap(); setNewCallOpen(true); }}
            onLongPress={handleSimulateIncoming}
            hitSlop={10}
          >
            <Ionicons name="add-circle-outline" size={23} color={colors.accent} />
          </Pressable>
        </View>
      </View>

      <FilterChips options={CALL_FILTERS} value={filter} onChange={setFilter} />

      {editing && selected.length > 0 ? (
        <Pressable onPress={handleDeleteSelected} style={({ pressed }) => [styles.bulkBar, pressed && { opacity: 0.75 }]}>
          <Text style={styles.bulkBarText}>Delete {selected.length} selected</Text>
        </Pressable>
      ) : null}

      {phase === 'loading' ? (
        <View style={{ paddingTop: space.md }}>
          <SkeletonList count={7} />
        </View>
      ) : phase === 'error' ? (
        <ErrorState message="Couldn't load your calls." onRetry={retry} />
      ) : (
        <SectionList
          sections={sections}
          keyExtractor={(c) => c.id}
          contentContainerStyle={{ paddingBottom: space.xl * 2, flexGrow: 1 }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.textMuted} />}
          renderSectionHeader={({ section }) => <Text style={styles.sectionLabel}>{section.title}</Text>}
          renderItem={({ item }) => (
            <CallRow
              call={item}
              onPress={() => router.push(`/call/${item.contactId}?type=${item.type}`)}
              onLongPress={() => { hapticTap(); setSheetCall(item); }}
              onCallBack={() => handleStartCall(item.contact, item.type)}
              onDelete={handleDelete}
              selectable={editing}
              selected={selected.includes(item.id)}
              onToggleSelect={toggleSelect}
            />
          )}
          ListEmptyComponent={
            <EmptyState icon="call-outline" title="No calls" message="Calls you make and receive will show up here." />
          }
        />
      )}

      <NewCallSheet visible={newCallOpen} onClose={() => setNewCallOpen(false)} onCall={handleStartCall} />
      <ActionSheet
        visible={!!sheetCall}
        onClose={() => setSheetCall(null)}
        title={sheetCall?.contact?.name}
        actions={sheetActions}
      />
    </View>
  );
}

function getStyles(colors) {
  return StyleSheet.create({
    screen: { flex: 1, backgroundColor: colors.bg },
    header: {
      flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
      paddingHorizontal: space.lg, paddingTop: space.sm, paddingBottom: space.xs, minHeight: 40,
    },
    title: { ...type.h1, fontSize: 17, color: colors.textPrimary },
    headerAction: { ...type.body, color: colors.accent, fontWeight: '600' },
    sectionLabel: {
      ...type.small, color: colors.textMuted, fontWeight: '700',
      textTransform: 'uppercase', letterSpacing: 0.6,
      marginTop: space.md, marginBottom: space.xs, marginLeft: space.lg, backgroundColor: colors.bg,
    },
    bulkBar: { backgroundColor: colors.dangerDim, paddingVertical: space.sm, alignItems: 'center' },
    bulkBarText: { ...type.small, color: colors.danger, fontWeight: '700' },
  });
}
