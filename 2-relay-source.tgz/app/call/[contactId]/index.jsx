import { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, Pressable, StyleSheet, Animated, Easing } from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { avatarPalette } from '../../../theme';
import { fetchConversation } from '../../../messagesApi';
import { placeCall, recordCall } from '../../../callsApi';
import CallKeypad from '../../../components/CallKeypad';
import CallParticipantSheet from '../../../components/CallParticipantSheet';
import { hapticTap, hapticBurst } from '../../../utils/haptics';
import { usePressScale } from '../../../utils/motion';

function hashColor(id) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return avatarPalette[h % avatarPalette.length];
}
function initials(name) {
  const parts = name.trim().split(/\s+/);
  return parts.length === 1 ? parts[0][0].toUpperCase() : (parts[0][0] + parts[1][0]).toUpperCase();
}
function elapsedLabel(sec) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

// Full-screen Telegram-style in-call UI. Always dark, regardless of app
// theme — matches iOS's own call screens. `type` (voice|video) comes
// from the query string; the call itself is simulated (ring → connect)
// since there's no real signaling backend here — see callsApi.js.
//
// `direction` distinguishes the two ways this screen is reached:
//  - outgoing (default): pushed directly, so it drives its own
//    ringing → connected simulation via placeCall().
//  - incoming: pushed by call/[contactId]/incoming.jsx *after* the
//    person already tapped Accept there, so it's connected immediately
//    and skips the ringing phase entirely.
export default function ActiveCallScreen() {
  const { contactId, type = 'voice', direction = 'outgoing' } = useLocalSearchParams();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const isVideo = type === 'video';
  const isIncoming = direction === 'incoming';

  const [contact, setContact] = useState(null);
  const [phase, setPhase] = useState(isIncoming ? 'connected' : 'ringing'); // ringing | connected | ended
  const [elapsed, setElapsed] = useState(0);
  const [muted, setMuted] = useState(false);
  const [speaker, setSpeaker] = useState(isVideo);
  const [bluetooth, setBluetooth] = useState(false);
  const [onHold, setOnHold] = useState(false);
  const [cameraOff, setCameraOff] = useState(false);
  const [keypadOpen, setKeypadOpen] = useState(false);
  const [addParticipantOpen, setAddParticipantOpen] = useState(false);
  const [participants, setParticipants] = useState([]);

  const pulse = useRef(new Animated.Value(1)).current;
  const endedRef = useRef(false);
  const elapsedRef = useRef(0);

  useEffect(() => {
    fetchConversation(contactId).then(setContact);

    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1.12, duration: 700, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 1, duration: 700, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      ])
    );

    if (isIncoming) {
      // Already answered on the incoming screen — nothing to ring here.
      return () => { if (!endedRef.current) finish(); };
    }

    loop.start();
    placeCall(contactId, type, { onConnected: () => setPhase('connected') });

    return () => {
      loop.stop();
      // If the person navigates away without tapping "end call" (e.g.
      // swipe-back), still log whatever happened so it shows in history.
      if (!endedRef.current) finish();
    };
  }, [contactId]);

  useEffect(() => {
    if (phase !== 'connected' || onHold) return;
    const id = setInterval(() => {
      elapsedRef.current += 1;
      setElapsed(elapsedRef.current);
    }, 1000);
    return () => clearInterval(id);
  }, [phase, onHold]);

  function finish() {
    if (endedRef.current) return;
    endedRef.current = true;
    recordCall({
      contactId,
      direction,
      type,
      status: isIncoming || elapsedRef.current > 0 ? 'answered' : 'missed',
      durationSec: elapsedRef.current,
      at: Date.now(),
    });
  }

  function handleEnd() {
    hapticBurst();
    setPhase('ended');
    finish();
    setTimeout(() => (router.canGoBack() ? router.back() : router.replace('/(tabs)/calls')), 250);
  }

  function toggleSpeaker() {
    hapticTap();
    setSpeaker((v) => {
      const next = !v;
      if (next) setBluetooth(false);
      return next;
    });
  }

  function toggleBluetooth() {
    hapticTap();
    setBluetooth((v) => {
      const next = !v;
      if (next) setSpeaker(false);
      return next;
    });
  }

  function addParticipant(person) {
    hapticTap();
    setParticipants((list) => (list.some((p) => p.id === person.id) ? list : [...list, person]));
  }

  const name = contact?.name || 'Calling…';
  const statusText = onHold
    ? 'On hold'
    : phase === 'ringing'
    ? (isVideo ? 'Video calling…' : 'Calling…')
    : phase === 'connected'
    ? elapsedLabel(elapsed)
    : 'Call ended';

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ headerShown: false }} />

      {isVideo && phase === 'connected' && !cameraOff ? (
        <View style={[styles.videoBg, { backgroundColor: contact?.avatarColor || hashColor(contactId) }]} />
      ) : null}

      <View style={[styles.top, { paddingTop: insets.top + 24 }]}>
        {!isVideo || phase !== 'connected' || cameraOff ? (
          <Animated.View style={[styles.avatarRing, phase === 'ringing' && { transform: [{ scale: pulse }] }, onHold && { opacity: 0.5 }]}>
            <View style={[styles.avatar, { backgroundColor: contact?.avatarColor || hashColor(contactId) }]}>
              <Text style={styles.avatarText}>{contact ? initials(contact.name) : ''}</Text>
            </View>
          </Animated.View>
        ) : null}
        <Text style={styles.name}>{name}</Text>
        <Text style={styles.status}>{statusText}</Text>

        {!isVideo && participants.length > 0 ? (
          <View style={styles.participantsRow}>
            {participants.map((p) => (
              <View key={p.id} style={styles.participantChip}>
                <View style={[styles.participantDot, { backgroundColor: p.avatarColor || hashColor(p.id) }]} />
                <Text style={styles.participantName} numberOfLines={1}>{p.name}</Text>
              </View>
            ))}
          </View>
        ) : null}
      </View>

      {isVideo && phase === 'connected' ? (
        <View style={styles.selfPreview}>
          <Ionicons name={cameraOff ? 'videocam-off' : 'person'} size={22} color="rgba(255,255,255,0.7)" />
        </View>
      ) : null}

      <View style={[styles.controls, { paddingBottom: insets.bottom + 28 }]}>
        {isVideo ? (
          <View style={styles.controlRow}>
            <CallButton icon={muted ? 'mic-off' : 'mic'} active={muted} onPress={() => { hapticTap(); setMuted((v) => !v); }} label="Mute" />
            <CallButton icon={cameraOff ? 'videocam-off' : 'videocam'} active={cameraOff} onPress={() => { hapticTap(); setCameraOff((v) => !v); }} label="Camera" />
            <CallButton icon="keypad" onPress={() => { hapticTap(); setKeypadOpen(true); }} label="Keypad" />
          </View>
        ) : (
          <View style={styles.grid}>
            <View style={styles.controlRow}>
              <CallButton icon={muted ? 'mic-off' : 'mic'} active={muted} onPress={() => { hapticTap(); setMuted((v) => !v); }} label="Mute" />
              <CallButton icon="volume-high" active={speaker} onPress={toggleSpeaker} label="Speaker" />
              <CallButton icon="bluetooth" active={bluetooth} onPress={toggleBluetooth} label="Bluetooth" />
            </View>
            <View style={styles.controlRow}>
              <CallButton icon="keypad" onPress={() => { hapticTap(); setKeypadOpen(true); }} label="Keypad" />
              <CallButton icon="person-add" onPress={() => { hapticTap(); setAddParticipantOpen(true); }} label="Add" />
              <CallButton icon="pause" active={onHold} onPress={() => { hapticTap(); setOnHold((v) => !v); }} label="Hold" />
            </View>
          </View>
        )}

        <EndCallButton onPress={handleEnd} />
      </View>

      <CallKeypad visible={keypadOpen} onClose={() => setKeypadOpen(false)} />
      <CallParticipantSheet
        visible={addParticipantOpen}
        excludeIds={[String(contactId), ...participants.map((p) => p.id)]}
        onClose={() => setAddParticipantOpen(false)}
        onAdd={addParticipant}
      />
    </View>
  );
}

function CallButton({ icon, active, onPress, label }) {
  const { style, onPressIn, onPressOut } = usePressScale(0.88);
  return (
    <View style={styles.btnWrap}>
      <Animated.View style={style}>
        <Pressable onPress={onPress} onPressIn={onPressIn} onPressOut={onPressOut} style={[styles.ctrlBtn, active && styles.ctrlBtnActive]}>
          <Ionicons name={icon} size={22} color={active ? '#14181C' : '#FFFFFF'} />
        </Pressable>
      </Animated.View>
      <Text style={styles.btnLabel}>{label}</Text>
    </View>
  );
}

function EndCallButton({ onPress }) {
  const { style, onPressIn, onPressOut } = usePressScale(0.9);
  return (
    <Animated.View style={style}>
      <Pressable onPress={onPress} onPressIn={onPressIn} onPressOut={onPressOut} style={styles.endBtn}>
        <Ionicons name="call" size={28} color="#FFFFFF" style={{ transform: [{ rotate: '135deg' }] }} />
      </Pressable>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#0B0D10' },
  videoBg: { ...StyleSheet.absoluteFillObject, opacity: 0.35 },
  top: { alignItems: 'center', paddingHorizontal: 24 },
  avatarRing: { marginBottom: 18 },
  avatar: { width: 116, height: 116, borderRadius: 58, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#F2F4F6', fontSize: 40, fontWeight: '600' },
  name: { color: '#F2F4F6', fontSize: 26, fontWeight: '600', marginBottom: 6 },
  status: { color: 'rgba(242,244,246,0.65)', fontSize: 15 },
  participantsRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 8, marginTop: 16, paddingHorizontal: 12 },
  participantChip: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 14, paddingVertical: 5, paddingHorizontal: 10 },
  participantDot: { width: 8, height: 8, borderRadius: 4 },
  participantName: { color: 'rgba(242,244,246,0.85)', fontSize: 12, fontWeight: '500', maxWidth: 100 },
  selfPreview: {
    position: 'absolute', top: 60, right: 20, width: 84, height: 118, borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.12)', alignItems: 'center', justifyContent: 'center',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)',
  },
  controls: { position: 'absolute', bottom: 0, left: 0, right: 0, alignItems: 'center', gap: 30 },
  grid: { gap: 22 },
  controlRow: { flexDirection: 'row', gap: 28 },
  btnWrap: { alignItems: 'center', gap: 8 },
  ctrlBtn: {
    width: 60, height: 60, borderRadius: 30, alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.14)',
  },
  ctrlBtnActive: { backgroundColor: '#F2F4F6' },
  btnLabel: { color: 'rgba(242,244,246,0.75)', fontSize: 12, fontWeight: '500' },
  endBtn: {
    width: 68, height: 68, borderRadius: 34, backgroundColor: '#E5584D',
    alignItems: 'center', justifyContent: 'center',
  },
});
