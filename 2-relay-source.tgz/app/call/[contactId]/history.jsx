import { useCallback, useMemo, useState } from 'react';
import { View, Text, FlatList, Pressable, RefreshControl, StyleSheet } from 'react-native';
import { useLocalSearchParams, useRouter, useFocusEffect, Stack } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { type, space, avatarPalette, useTheme } from '../../../theme';
import CallRow from '../../../components/CallRow';
import { SkeletonCircle, SkeletonList } from '../../../components/Skeleton';
import { EmptyState, ErrorState } from '../../../components/StateViews';
import { useToast } from '../../../components/Toast';
import { useConfirm } from '../../../components/ConfirmDialog';
import { hapticTap } from '../../../utils/haptics';
import { fetchConversation } from '../../../messagesApi';
import { fetchCallsForContact, deleteCall, clearContactHistory } from '../../../callsApi';

function hashColor(id) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return avatarPalette[h % avatarPalette.length];
}
function initials(name) {
  const parts = name.trim().split(/\s+/);
  return parts.length === 1 ? parts[0][0].toUpperCase() : (parts[0][0] + parts[1][0]).toUpperCase();
}

// Per-contact call log — Telegram's "Call history" from the calls list
// long-press menu: every past call with this person, plus quick redial.
export default function ContactCallHistoryScreen() {
  const { contactId } = useLocalSearchParams();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const styles = useMemo(() => getStyles(colors), [colors]);
  const toast = useToast();
  const confirm = useConfirm();

  const [contact, setContact] = useState(null);
  const [calls, setCalls] = useState([]);
  const [phase, setPhase] = useState('loading'); // 'loading' | 'ready' | 'error'
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const [c, calls] = await Promise.all([
        fetchConversation(contactId),
        fetchCallsForContact(contactId),
      ]);
      setContact(c);
      setCalls(calls);
      setPhase('ready');
    } catch (e) {
      setPhase('error');
    }
  }, [contactId]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function onRefresh() {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }

  async function retry() {
    setPhase('loading');
    await load();
  }

  async function handleDelete(call) {
    try {
      await deleteCall(call.id);
      await load();
    } catch (e) {
      toast.error("Couldn't delete that call");
    }
  }

  async function handleClear() {
    const ok = await confirm({
      title: 'Delete history?',
      message: `Delete all calls with ${contact?.name || 'this contact'}?`,
      confirmLabel: 'Delete',
      destructive: true,
      onConfirm: async () => {
        await clearContactHistory(contactId);
        await load();
      },
    });
    if (ok) toast.success('Call history cleared');
  }

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={[styles.header, { paddingTop: insets.top + space.xs }]}>
        <Pressable onPress={() => router.back()} hitSlop={10}>
          <Ionicons name="chevron-back" size={26} color={colors.accent} />
        </Pressable>
        <Text style={styles.headerTitle} numberOfLines={1}>{contact?.name || 'Call history'}</Text>
        <Pressable onPress={handleClear} hitSlop={10} disabled={phase !== 'ready' || !calls.length}>
          <Ionicons name="trash-outline" size={21} color={phase !== 'ready' || !calls.length ? colors.textMuted : colors.danger} />
        </Pressable>
      </View>

      {phase === 'loading' ? (
        <View style={{ padding: space.lg }}>
          <View style={{ alignItems: 'center', gap: space.md, marginBottom: space.lg }}>
            <SkeletonCircle size={76} />
          </View>
          <SkeletonList count={4} />
        </View>
      ) : phase === 'error' ? (
        <ErrorState message="Couldn't load this call history." onRetry={retry} />
      ) : (
        <>
          {contact ? (
            <View style={styles.profile}>
              <View style={[styles.avatar, { backgroundColor: contact.avatarColor || hashColor(contactId) }]}>
                <Text style={styles.avatarText}>{initials(contact.name)}</Text>
              </View>
              <View style={styles.quickActions}>
                <Pressable style={styles.quickBtn} onPress={() => { hapticTap(); router.push(`/call/${contactId}?type=voice`); }}>
                  <Ionicons name="call" size={19} color={colors.accent} />
                  <Text style={styles.quickLabel}>Call</Text>
                </Pressable>
                <Pressable style={styles.quickBtn} onPress={() => { hapticTap(); router.push(`/call/${contactId}?type=video`); }}>
                  <Ionicons name="videocam" size={20} color={colors.accent} />
                  <Text style={styles.quickLabel}>Video</Text>
                </Pressable>
              </View>
            </View>
          ) : null}

          <FlatList
            data={calls}
            keyExtractor={(c) => c.id}
            contentContainerStyle={{ paddingBottom: space.xl * 2, flexGrow: 1 }}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.textMuted} />}
            renderItem={({ item }) => (
              <CallRow
                call={item}
                onPress={() => router.push(`/call/${contactId}?type=${item.type}`)}
                onCallBack={() => router.push(`/call/${contactId}?type=${item.type}`)}
                onDelete={handleDelete}
              />
            )}
            ListEmptyComponent={
              <EmptyState icon="call-outline" title="No calls yet" message="Calls with this contact will show up here." />
            }
          />
        </>
      )}
    </View>
  );
}

function getStyles(colors) {
  return StyleSheet.create({
    screen: { flex: 1, backgroundColor: colors.bg },
    header: {
      flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
      paddingHorizontal: space.lg, paddingBottom: space.sm,
    },
    headerTitle: { ...type.h1, fontSize: 16, color: colors.textPrimary, flex: 1, textAlign: 'center' },
    profile: { alignItems: 'center', paddingVertical: space.lg, gap: space.md },
    avatar: { width: 76, height: 76, borderRadius: 38, alignItems: 'center', justifyContent: 'center' },
    avatarText: { color: '#F2F4F6', fontSize: 26, fontWeight: '600' },
    quickActions: { flexDirection: 'row', gap: space.xl },
    quickBtn: { alignItems: 'center', gap: 4 },
    quickLabel: { ...type.small, color: colors.accent, fontWeight: '600' },
  });
}
