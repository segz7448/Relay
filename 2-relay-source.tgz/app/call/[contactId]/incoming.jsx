import { useEffect, useRef, useState } from 'react';
import { View, Text, Pressable, StyleSheet, Animated, Easing } from 'react-native';
import { useLocalSearchParams, useRouter, Stack } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { avatarPalette } from '../../../theme';
import { fetchConversation } from '../../../messagesApi';
import { recordCall } from '../../../callsApi';
import { hapticBurst, hapticTap } from '../../../utils/haptics';
import { usePressScale } from '../../../utils/motion';
import QuickReplySheet from '../../../components/QuickReplySheet';

function CircleButton({ onPress, style, children }) {
  const { style: pressStyle, onPressIn, onPressOut } = usePressScale(0.9);
  return (
    <Animated.View style={pressStyle}>
      <Pressable onPress={onPress} onPressIn={onPressIn} onPressOut={onPressOut} style={style}>
        {children}
      </Pressable>
    </Animated.View>
  );
}

function hashColor(id) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return avatarPalette[h % avatarPalette.length];
}
function initials(name) {
  const parts = name.trim().split(/\s+/);
  return parts.length === 1 ? parts[0][0].toUpperCase() : (parts[0][0] + parts[1][0]).toUpperCase();
}

// Full-screen incoming-call UI — the CallKit-style screen that would be
// shown by a native push, simulated here since there's no signaling
// backend (see callsApi.randomCallableContact, the demo entry point).
// Three outcomes: Accept (hands off to the active-call screen already
// connected), Decline (logs a missed call), or Message instead (logs a
// missed call and hands the person to the conversation with a canned
// or blank reply ready to send).
export default function IncomingCallScreen() {
  const { contactId, type = 'voice' } = useLocalSearchParams();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const isVideo = type === 'video';

  const [contact, setContact] = useState(null);
  const [quickReplyOpen, setQuickReplyOpen] = useState(false);
  const settledRef = useRef(false);

  const ring1 = useRef(new Animated.Value(0)).current;
  const ring2 = useRef(new Animated.Value(0)).current;
  const breathe = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    fetchConversation(contactId).then(setContact);

    function ringLoop(anim, delay) {
      return Animated.loop(
        Animated.sequence([
          Animated.delay(delay),
          Animated.timing(anim, { toValue: 1, duration: 1600, easing: Easing.out(Easing.quad), useNativeDriver: true }),
          Animated.timing(anim, { toValue: 0, duration: 0, useNativeDriver: true }),
        ])
      );
    }
    const l1 = ringLoop(ring1, 0);
    const l2 = ringLoop(ring2, 800);
    const breatheLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(breathe, { toValue: 1.06, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(breathe, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      ])
    );
    l1.start();
    l2.start();
    breatheLoop.start();

    hapticBurst();
    const buzz = setInterval(hapticBurst, 1500);

    return () => {
      l1.stop();
      l2.stop();
      breatheLoop.stop();
      clearInterval(buzz);
      // Swiped away / navigated off without a decision — treat like a
      // missed call rather than losing the log entry silently.
      if (!settledRef.current) logOutcome('missed');
    };
  }, [contactId]);

  function logOutcome(status) {
    if (settledRef.current) return;
    settledRef.current = true;
    recordCall({ contactId, direction: 'incoming', type, status, durationSec: 0, at: Date.now() });
  }

  function safeBack(fallback) {
    if (router.canGoBack()) router.back();
    else router.replace(fallback);
  }

  function handleAccept() {
    settledRef.current = true; // recorded by the active-call screen instead
    router.replace(`/call/${contactId}?type=${type}&direction=incoming`);
  }

  function handleDecline() {
    logOutcome('missed');
    safeBack('/(tabs)/calls');
  }

  function handleQuickReply(text) {
    logOutcome('missed');
    setQuickReplyOpen(false);
    const suffix = text ? `?prefill=${encodeURIComponent(text)}` : '';
    router.replace(`/conversation/${contactId}${suffix}`);
  }

  const name = contact?.name || 'Unknown';
  const ringScale1 = ring1.interpolate({ inputRange: [0, 1], outputRange: [1, 1.55] });
  const ringOpacity1 = ring1.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0] });
  const ringScale2 = ring2.interpolate({ inputRange: [0, 1], outputRange: [1, 1.55] });
  const ringOpacity2 = ring2.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0] });
  const avatarColor = contact?.avatarColor || hashColor(String(contactId));

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={[styles.glow, { backgroundColor: avatarColor }]} />

      <View style={[styles.top, { paddingTop: insets.top + 36 }]}>
        <Text style={styles.kicker}>{isVideo ? 'Incoming video call' : 'Incoming voice call'}</Text>

        <View style={styles.avatarWrap}>
          <Animated.View style={[styles.ring, { backgroundColor: avatarColor, transform: [{ scale: ringScale1 }], opacity: ringOpacity1 }]} />
          <Animated.View style={[styles.ring, { backgroundColor: avatarColor, transform: [{ scale: ringScale2 }], opacity: ringOpacity2 }]} />
          <Animated.View style={{ transform: [{ scale: breathe }] }}>
            <View style={[styles.avatar, { backgroundColor: avatarColor }]}>
              <Text style={styles.avatarText}>{contact ? initials(contact.name) : ''}</Text>
            </View>
          </Animated.View>
        </View>

        <Text style={styles.name}>{name}</Text>
        <Text style={styles.status}>Botmanager {isVideo ? 'video' : 'audio'}</Text>
      </View>

      <View style={[styles.bottom, { paddingBottom: insets.bottom + 20 }]}>
        <Pressable onPress={() => { hapticTap(); setQuickReplyOpen(true); }} style={({ pressed }) => [styles.messageBtn, pressed && { opacity: 0.6 }]} hitSlop={8}>
          <Ionicons name="chatbubble-ellipses" size={16} color="rgba(255,255,255,0.85)" />
          <Text style={styles.messageLabel}>Message instead</Text>
        </Pressable>

        <View style={styles.actionsRow}>
          <View style={styles.actionCol}>
            <CircleButton onPress={() => { hapticTap(); handleDecline(); }} style={[styles.circleBtn, styles.decline]}>
              <Ionicons name="call" size={30} color="#FFFFFF" style={{ transform: [{ rotate: '135deg' }] }} />
            </CircleButton>
            <Text style={styles.actionLabel}>Decline</Text>
          </View>
          <View style={styles.actionCol}>
            <CircleButton onPress={() => { hapticBurst(); handleAccept(); }} style={[styles.circleBtn, styles.accept]}>
              <Ionicons name={isVideo ? 'videocam' : 'call'} size={30} color="#FFFFFF" />
            </CircleButton>
            <Text style={styles.actionLabel}>Accept</Text>
          </View>
        </View>
      </View>

      <QuickReplySheet visible={quickReplyOpen} onClose={() => setQuickReplyOpen(false)} onPick={handleQuickReply} />
    </View>
  );
}

const AVATAR_SIZE = 128;

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#0B0D10' },
  glow: { ...StyleSheet.absoluteFillObject, opacity: 0.18 },
  top: { flex: 1, alignItems: 'center', paddingHorizontal: 24 },
  kicker: { color: 'rgba(242,244,246,0.6)', fontSize: 13, fontWeight: '600', letterSpacing: 0.3, marginBottom: 28 },
  avatarWrap: { alignItems: 'center', justifyContent: 'center', width: AVATAR_SIZE, height: AVATAR_SIZE, marginBottom: 22 },
  ring: { position: 'absolute', width: AVATAR_SIZE, height: AVATAR_SIZE, borderRadius: AVATAR_SIZE / 2 },
  avatar: { width: AVATAR_SIZE, height: AVATAR_SIZE, borderRadius: AVATAR_SIZE / 2, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#F2F4F6', fontSize: 44, fontWeight: '600' },
  name: { color: '#F2F4F6', fontSize: 27, fontWeight: '600', marginBottom: 6 },
  status: { color: 'rgba(242,244,246,0.6)', fontSize: 15 },
  bottom: { alignItems: 'center', gap: 26 },
  messageBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 8, paddingHorizontal: 14 },
  messageLabel: { color: 'rgba(255,255,255,0.85)', fontSize: 14, fontWeight: '500' },
  actionsRow: { flexDirection: 'row', gap: 64, paddingHorizontal: 24 },
  actionCol: { alignItems: 'center', gap: 10 },
  circleBtn: { width: 72, height: 72, borderRadius: 36, alignItems: 'center', justifyContent: 'center' },
  decline: { backgroundColor: '#E5584D' },
  accept: { backgroundColor: '#4FD1A5' },
  actionLabel: { color: 'rgba(242,244,246,0.75)', fontSize: 13, fontWeight: '500' },
});
