import { useCallback, useMemo, useState } from 'react';
import { View, Text, FlatList, RefreshControl, StyleSheet } from 'react-native';
import { useLocalSearchParams, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { type, space, radius, useTheme } from '../../../theme';
import { SkeletonList } from '../../../components/Skeleton';
import { EmptyState, ErrorState } from '../../../components/StateViews';
import { searchFiles } from '../../../messagesApi';

const KIND_ICON = {
  image: 'image-outline',
  video: 'videocam-outline',
  document: 'document-text-outline',
  voice: 'mic-outline',
  link: 'link-outline',
};

function dateLabel(ts) {
  return new Date(ts).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

export default function BotFilesScreen() {
  const { id } = useLocalSearchParams();
  const { colors } = useTheme();
  const styles = useMemo(() => getStyles(colors), [colors]);
  const [files, setFiles] = useState(null);
  const [phase, setPhase] = useState('loading'); // 'loading' | 'ready' | 'error'
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async () => {
    try {
      const all = await searchFiles('');
      setFiles(all.filter((f) => f.conversationId === id));
      setPhase('ready');
    } catch (e) {
      setPhase('error');
    }
  }, [id]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  async function onRefresh() {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  }

  async function retry() {
    setPhase('loading');
    await load();
  }

  if (phase === 'loading') {
    return (
      <View style={styles.screen}>
        <View style={{ paddingTop: space.md }}>
          <SkeletonList count={5} />
        </View>
      </View>
    );
  }

  if (phase === 'error') {
    return (
      <View style={styles.screen}>
        <ErrorState message="Couldn't load shared files." onRetry={retry} />
      </View>
    );
  }

  return (
    <View style={styles.screen}>
      <FlatList
        data={files}
        keyExtractor={(f) => f.messageId}
        contentContainerStyle={{ padding: space.lg, paddingBottom: space.xl * 2, flexGrow: 1 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.textMuted} />}
        ListHeaderComponent={
          files.length ? (
            <Text style={styles.helperTop}>{files.length} file{files.length === 1 ? '' : 's'} and link{files.length === 1 ? '' : 's'} shared in this chat.</Text>
          ) : null
        }
        renderItem={({ item }) => (
          <View style={styles.row}>
            <View style={styles.icon}>
              <Ionicons name={KIND_ICON[item.attachment.kind] || 'document-outline'} size={17} color={colors.textSecondary} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.name} numberOfLines={1}>{item.attachment.name}</Text>
              <Text style={styles.meta}>{dateLabel(item.createdAt)}</Text>
            </View>
          </View>
        )}
        ListEmptyComponent={<EmptyState icon="folder-open-outline" title="Nothing shared yet" message="Files and links exchanged with this bot will show up here." />}
      />
    </View>
  );
}

function getStyles(colors) {
  return StyleSheet.create({
    screen: { flex: 1, backgroundColor: colors.bg },
    helperTop: { ...type.small, color: colors.textMuted, marginBottom: space.lg },
    row: {
      flexDirection: 'row', alignItems: 'center', gap: space.md,
      backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border,
      borderRadius: radius.md, padding: space.md, marginBottom: space.sm,
    },
    icon: {
      width: 34, height: 34, borderRadius: radius.sm, backgroundColor: colors.surfaceRaised,
      alignItems: 'center', justifyContent: 'center',
    },
    name: { ...type.body, color: colors.textPrimary },
    meta: { ...type.small, color: colors.textMuted, marginTop: 2 },
  });
}
