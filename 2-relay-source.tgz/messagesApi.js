// messagesApi.js — REAL conversation + message data.
// Same exports/shapes as the original mock.

import { api } from './api';

// In-memory overlay for optimistic conversation mutations
// (pin, mute, addConversation, removeConversation, patchConversation).
// These are called synchronously from botsApi, so they also fire real API
// calls to keep the backend in sync.

let _overlay = {}; // id -> partial conversation fields
let _added = [];   // conversations created locally (before server sync)
let _removed = new Set(); // ids removed locally

function withOverlay(conv) {
  return { ...conv, ...(_overlay[conv.id] ?? {}) };
}

export async function fetchConversations() {
  try {
    const convs = await api.listConversations();
    // Merge any local additions or removals
    const base = convs.filter(c => !_removed.has(c.id)).map(withOverlay);
    const addedNotInBase = _added.filter(a => !base.find(b => b.id === a.id));
    return [...base, ...addedNotInBase].sort((a, b) => {
      if (a.pinned && !b.pinned) return -1;
      if (!a.pinned && b.pinned) return 1;
      return (b.lastMessageAt || 0) - (a.lastMessageAt || 0);
    });
  } catch {
    // Fallback to local if offline
    return _added;
  }
}

export async function fetchConversation(id) {
  try {
    const conv = await api.getConversation(id);
    return withOverlay(conv);
  } catch {
    return _added.find(c => c.id === id) ?? null;
  }
}

export async function fetchMessages(conversationId, { limit = 50, before } = {}) {
  const params = { limit: String(limit) };
  if (before) params.before = String(before);
  const res = await api.listMessages(conversationId, params);
  return res?.messages ?? res ?? [];
}

export async function sendMessage(conversationId, body) {
  return api.sendMessage(conversationId, body);
}

export async function markConversationRead(id) {
  await api.updateConversation(id, { unreadCount: 0 }).catch(() => {});
}

export async function pinConversation(id, pinned) {
  _overlay[id] = { ...(_overlay[id] ?? {}), pinned };
  await api.updateConversation(id, { pinned }).catch(() => {});
}

export async function muteConversation(id, muted) {
  _overlay[id] = { ...(_overlay[id] ?? {}), muted };
  await api.updateConversation(id, { muted }).catch(() => {});
}

export async function deleteConversation(id) {
  _removed.add(id);
  _added = _added.filter(c => c.id !== id);
  await api.deleteConversation(id).catch(() => {});
}

// Called by botsApi when a bot is created/modified/deleted
export async function addConversation(conv) {
  _added = _added.filter(c => c.id !== conv.id);
  _added.unshift(conv);
  // Persist to backend
  await api.createConversation({
    kind: conv.kind,
    name: conv.name,
    avatarColor: conv.avatarColor,
    bio: conv.bio ?? '',
    refId: conv.id,
  }).catch(() => {});
}

export async function removeConversation(id) {
  _removed.add(id);
  _added = _added.filter(c => c.id !== id);
  await api.deleteConversation(id).catch(() => {});
}

export async function patchConversation(id, patch) {
  _overlay[id] = { ...(_overlay[id] ?? {}), ...patch };
  await api.updateConversation(id, patch).catch(() => {});
}

export async function reactToMessage(convId, msgId, emoji) {
  return api.reactToMessage(convId, msgId, emoji);
}

// ── Search ───────────────────────────────────────────────────────────────────

export async function searchMessages(query) {
  try {
    const res = await api.searchConversations(query);
    return res?.messages ?? [];
  } catch {
    return [];
  }
}

export async function searchFiles(query, kinds = []) {
  try {
    const res = await api.searchConversations(query, kinds);
    return res?.files ?? [];
  } catch {
    return [];
  }
}

// There's no public cross-account directory to browse (accounts are
// provisioned directly in D1 by the app owner — there's no social graph
// to search). "Usernames" search is scoped to people you already have a
// direct conversation with, matched against their name. (Implemented in
// privacyApi.js — searchDirectory — since that's where every screen
// imports it from; startDirectConversation lives here since it operates
// on conversations.)
export function startDirectConversation(user) {
  // `user` here comes from searchDirectory() and is always an existing
  // conversation, so "starting" it is just handing back its id.
  return user.id;
}

// ── Forwarding ───────────────────────────────────────────────────────────────

export async function forwardMessage(message, targetIds, originName) {
  const prefix = originName ? `Forwarded from ${originName}:\n` : '';
  await Promise.all(targetIds.map((targetId) =>
    api.sendMessage(targetId, {
      text: message.text ? `${prefix}${message.text}` : (prefix || undefined),
      kind: message.kind,
      attachmentUrl: message.attachmentUrl,
      attachmentType: message.attachmentType,
      attachmentName: message.attachmentName,
      attachmentSize: message.attachmentSize,
      durationSec: message.durationSec,
    })
  ));
}

