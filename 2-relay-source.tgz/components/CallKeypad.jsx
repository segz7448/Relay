import { useState } from 'react';
import { Modal, Pressable, View, Text, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { hapticTap } from '../utils/haptics';

// iOS in-call keypad: digits + letters underneath, entered digits echoed
// above the grid, a "Hide" bar to dismiss. Purely local — there's no
// live call leg to actually send DTMF tones down, so key taps just
// append to the on-screen readout (with a light haptic-style tap via
// native feedback the Pressable itself provides).
const KEYS = [
  ['1', ''], ['2', 'ABC'], ['3', 'DEF'],
  ['4', 'GHI'], ['5', 'JKL'], ['6', 'MNO'],
  ['7', 'PQRS'], ['8', 'TUV'], ['9', 'WXYZ'],
  ['*', ''], ['0', '+'], ['#', ''],
];

export default function CallKeypad({ visible, onClose }) {
  const insets = useSafeAreaInsets();
  const [digits, setDigits] = useState('');

  function handleClose() {
    setDigits('');
    onClose?.();
  }

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={handleClose}>
      <View style={styles.backdrop}>
        <Pressable style={{ flex: 1 }} onPress={handleClose} />
        <View style={[styles.sheet, { paddingBottom: insets.bottom + 20 }]}>
          <View style={styles.grabber} />
          <Text style={styles.readout} numberOfLines={1}>{digits || ' '}</Text>

          <View style={styles.grid}>
            {KEYS.map(([digit, letters]) => (
              <Pressable
                key={digit}
                style={({ pressed }) => [styles.key, pressed && styles.keyPressed]}
                onPress={() => { hapticTap(); setDigits((d) => (d + digit).slice(-30)); }}
              >
                <Text style={styles.keyDigit}>{digit}</Text>
                {letters ? <Text style={styles.keyLetters}>{letters}</Text> : <View style={{ height: 11 }} />}
              </Pressable>
            ))}
          </View>

          <View style={styles.bottomRow}>
            <View style={{ width: 56 }} />
            {digits.length > 0 ? (
              <Pressable hitSlop={10} onPress={() => { hapticTap(); setDigits((d) => d.slice(0, -1)); }} style={styles.deleteBtn}>
                <Ionicons name="backspace-outline" size={22} color="#FFFFFF" />
              </Pressable>
            ) : (
              <View style={{ width: 56 }} />
            )}
            <Pressable onPress={handleClose} style={styles.hideBtn}>
              <Text style={styles.hideLabel}>Hide</Text>
            </Pressable>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const KEY_SIZE = 72;

const styles = StyleSheet.create({
  backdrop: { flex: 1, justifyContent: 'flex-end' },
  sheet: {
    backgroundColor: 'rgba(28,33,38,0.98)',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    alignItems: 'center',
    paddingTop: 10,
  },
  grabber: { width: 36, height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.25)', marginBottom: 14 },
  readout: { color: '#F2F4F6', fontSize: 30, fontWeight: '300', letterSpacing: 2, minHeight: 38, marginBottom: 10 },
  grid: { width: KEY_SIZE * 3 + 40, flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  key: {
    width: KEY_SIZE, height: KEY_SIZE, borderRadius: KEY_SIZE / 2, marginVertical: 8,
    backgroundColor: 'rgba(255,255,255,0.14)', alignItems: 'center', justifyContent: 'center',
  },
  keyPressed: { backgroundColor: 'rgba(255,255,255,0.28)' },
  keyDigit: { color: '#FFFFFF', fontSize: 28, fontWeight: '400' },
  keyLetters: { color: 'rgba(255,255,255,0.7)', fontSize: 10, fontWeight: '600', letterSpacing: 1.5, marginTop: 1 },
  bottomRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', width: '100%', paddingHorizontal: 28, marginTop: 8 },
  deleteBtn: { width: 56, alignItems: 'center' },
  hideBtn: { paddingVertical: 8 },
  hideLabel: { color: 'rgba(255,255,255,0.85)', fontSize: 16, fontWeight: '600' },
});
