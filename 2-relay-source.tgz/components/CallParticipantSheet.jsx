import { useEffect, useMemo, useState } from 'react';
import { Modal, Pressable, View, Text, StyleSheet, FlatList } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { avatarPalette } from '../theme';
import { fetchCallableContacts } from '../callsApi';
import { hapticTap } from '../utils/haptics';

function hashColor(id) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return avatarPalette[h % avatarPalette.length];
}
function initials(name) {
  const parts = name.trim().split(/\s+/);
  return parts.length === 1 ? parts[0][0].toUpperCase() : (parts[0][0] + parts[1][0]).toUpperCase();
}

// "Add participant" — turns the 1:1 call into a group call by ringing
// another callable contact/bot. No real conferencing leg exists, so
// picking someone just adds them to the on-screen roster; the active
// call screen renders them as connected immediately.
export default function CallParticipantSheet({ visible, excludeIds = [], onClose, onAdd }) {
  const insets = useSafeAreaInsets();
  const [contacts, setContacts] = useState([]);

  useEffect(() => {
    if (visible) fetchCallableContacts().then(setContacts);
  }, [visible]);

  const available = useMemo(
    () => contacts.filter((c) => !excludeIds.includes(c.id)),
    [contacts, excludeIds]
  );

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <Pressable style={styles.backdrop} onPress={onClose}>
        <Pressable style={[styles.sheet, { paddingBottom: insets.bottom + 16 }]} onPress={() => {}}>
          <View style={styles.grabber} />
          <Text style={styles.title}>Add Participant</Text>
          <FlatList
            data={available}
            keyExtractor={(c) => c.id}
            style={{ maxHeight: 360 }}
            ListEmptyComponent={<Text style={styles.empty}>Everyone callable is already in this call.</Text>}
            renderItem={({ item }) => (
              <Pressable
                style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}
                onPress={() => { hapticTap(); onAdd?.(item); onClose?.(); }}
              >
                <View style={[styles.avatar, { backgroundColor: item.avatarColor || hashColor(item.id) }]}>
                  <Text style={styles.avatarText}>{initials(item.name)}</Text>
                </View>
                <Text style={styles.name} numberOfLines={1}>{item.name}</Text>
                <Ionicons name="add-circle" size={24} color="#4FD1A5" />
              </Pressable>
            )}
          />
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: '#1C2126', borderTopLeftRadius: 20, borderTopRightRadius: 20, paddingTop: 10, paddingHorizontal: 16 },
  grabber: { width: 36, height: 4, borderRadius: 2, backgroundColor: 'rgba(255,255,255,0.25)', alignSelf: 'center', marginBottom: 14 },
  title: { color: '#F2F4F6', fontSize: 16, fontWeight: '700', marginBottom: 8 },
  empty: { color: 'rgba(242,244,246,0.55)', fontSize: 13, paddingVertical: 24, textAlign: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10 },
  rowPressed: { backgroundColor: 'rgba(255,255,255,0.06)' },
  avatar: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: '#F2F4F6', fontSize: 15, fontWeight: '600' },
  name: { flex: 1, color: '#F2F4F6', fontSize: 15, fontWeight: '500' },
});
