import { useMemo, useRef } from 'react';
import { Animated, PanResponder, Pressable, View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { type, space, avatarPalette, useTheme } from '../theme';

const ACTION_W = 76;
const RIGHT_MAX = ACTION_W; // swipe left reveals: delete
const AVATAR = 50;

function hashColor(id) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return avatarPalette[h % avatarPalette.length];
}

function initials(name) {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].slice(0, 1).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

function timeLabel(ts) {
  const diff = Date.now() - ts;
  const min = 60 * 1000, hr = 60 * min, day = 24 * hr;
  if (diff < min) return 'now';
  if (diff < hr) return `${Math.floor(diff / min)}m`;
  if (diff < day) return new Date(ts).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
  if (diff < 7 * day) return new Date(ts).toLocaleDateString(undefined, { weekday: 'short' });
  return new Date(ts).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

function durationLabel(sec) {
  if (!sec) return null;
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export default function CallRow({ call, onPress, onLongPress, onCallBack, onDelete, selectable, selected, onToggleSelect }) {
  const { colors } = useTheme();
  const styles = useMemo(() => getStyles(colors), [colors]);
  const translateX = useRef(new Animated.Value(0)).current;
  const offset = useRef(0);

  const panResponder = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: (_, g) => !selectable && Math.abs(g.dx) > 8 && Math.abs(g.dx) > Math.abs(g.dy),
      onPanResponderMove: (_, g) => {
        const next = Math.max(-RIGHT_MAX, Math.min(0, offset.current + g.dx));
        translateX.setValue(next);
      },
      onPanResponderRelease: (_, g) => {
        const proposed = offset.current + g.dx;
        const target = proposed < -ACTION_W / 2 ? -RIGHT_MAX : 0;
        offset.current = target;
        Animated.spring(translateX, { toValue: target, useNativeDriver: true, speed: 24, bounciness: 4 }).start();
      },
    })
  ).current;

  function closeSwipe() {
    offset.current = 0;
    Animated.spring(translateX, { toValue: 0, useNativeDriver: true, speed: 24, bounciness: 4 }).start();
  }

  const missed = call.status === 'missed';
  const directionIcon = call.direction === 'incoming' ? 'arrow-down-outline' : 'arrow-up-outline';
  const typeIcon = call.type === 'video' ? 'videocam' : 'call';
  const duration = durationLabel(call.durationSec);

  const subtitleParts = [
    missed ? 'Missed' : call.direction === 'incoming' ? 'Incoming' : 'Outgoing',
    call.type === 'video' ? 'video' : 'voice',
  ];
  if (duration) subtitleParts.push(duration);

  return (
    <View style={styles.wrap}>
      <View style={[styles.actionsRow, { right: 0 }]}>
        <Pressable onPress={() => { closeSwipe(); onDelete?.(call); }} style={[styles.actionBtn, { backgroundColor: colors.danger }]}>
          <Ionicons name="trash" size={19} color="#FFFFFF" />
          <Text style={styles.actionLabel}>Delete</Text>
        </Pressable>
      </View>

      <Animated.View style={{ transform: [{ translateX }], backgroundColor: colors.bg }} {...(selectable ? {} : panResponder.panHandlers)}>
        <Pressable
          onPress={() => (selectable ? onToggleSelect?.(call) : onPress?.(call))}
          onLongPress={() => onLongPress?.(call)}
          style={({ pressed }) => [styles.row, pressed && { backgroundColor: colors.surfaceRaised }]}
        >
          {selectable ? (
            <View style={styles.checkboxSlot}>
              <View style={[styles.checkbox, selected && styles.checkboxOn]}>
                {selected ? <Ionicons name="checkmark" size={14} color={colors.onAccent} /> : null}
              </View>
            </View>
          ) : (
            <View style={[styles.avatar, { backgroundColor: call.contact.avatarColor || hashColor(call.contactId) }]}>
              <Text style={styles.avatarText}>{initials(call.contact.name)}</Text>
            </View>
          )}

          <View style={styles.main}>
            <Text style={styles.name} numberOfLines={1}>{call.contact.name}</Text>
            <View style={styles.subtitleRow}>
              <Ionicons name={directionIcon} size={12} color={missed ? colors.danger : colors.textMuted} />
              <Text style={[styles.subtitle, missed && { color: colors.danger }]} numberOfLines={1}>
                {subtitleParts.join(' · ')}
              </Text>
            </View>
          </View>

          <Text style={styles.time}>{timeLabel(call.at)}</Text>
          <Pressable hitSlop={10} onPress={() => onCallBack?.(call)} style={styles.callBtn}>
            <Ionicons name={typeIcon} size={19} color={colors.accent} />
          </Pressable>
        </Pressable>
        <View style={styles.separator} />
      </Animated.View>
    </View>
  );
}

function getStyles(colors) {
  return StyleSheet.create({
    wrap: { position: 'relative', backgroundColor: colors.bg },
    actionsRow: { position: 'absolute', top: 0, bottom: 0, flexDirection: 'row' },
    actionBtn: { width: ACTION_W, alignItems: 'center', justifyContent: 'center', gap: 3 },
    actionLabel: { ...type.small, color: '#FFFFFF', fontWeight: '700' },
    row: {
      flexDirection: 'row', alignItems: 'center',
      paddingVertical: space.sm + 2, paddingHorizontal: space.lg, gap: space.md,
    },
    avatar: { width: AVATAR, height: AVATAR, borderRadius: AVATAR / 2, alignItems: 'center', justifyContent: 'center' },
    avatarText: { color: '#F2F4F6', fontSize: 17, fontWeight: '600' },
    checkboxSlot: { width: AVATAR, alignItems: 'center', justifyContent: 'center' },
    checkbox: { width: 26, height: 26, borderRadius: 13, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: colors.border },
    checkboxOn: { backgroundColor: colors.accent, borderColor: colors.accent },
    main: { flex: 1, justifyContent: 'center' },
    name: { ...type.h2, fontSize: 16, color: colors.textPrimary },
    subtitleRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 2 },
    subtitle: { ...type.small, color: colors.textMuted },
    time: { ...type.small, color: colors.textMuted, marginRight: space.sm },
    callBtn: { padding: 4 },
    separator: { height: StyleSheet.hairlineWidth, backgroundColor: colors.border, marginLeft: space.lg + AVATAR + space.md },
  });
}
