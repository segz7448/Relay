import { useEffect, useMemo, useState } from 'react';
import { Modal, Pressable, View, Text, StyleSheet, FlatList } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { type, space, radius, avatarPalette, useTheme } from '../theme';
import { fetchCallableContacts } from '../callsApi';
import { SkeletonList } from './Skeleton';
import { hapticTap } from '../utils/haptics';

function hashColor(id) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  return avatarPalette[h % avatarPalette.length];
}
function initials(name) {
  const parts = name.trim().split(/\s+/);
  return parts.length === 1 ? parts[0][0].toUpperCase() : (parts[0][0] + parts[1][0]).toUpperCase();
}

// Full-height bottom sheet listing every callable contact/bot, each with
// a dedicated voice and video button — one tap starts the call.
export default function NewCallSheet({ visible, onClose, onCall }) {
  const insets = useSafeAreaInsets();
  const { colors } = useTheme();
  const styles = useMemo(() => getStyles(colors), [colors]);
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!visible) return;
    setLoading(true);
    fetchCallableContacts().then((data) => {
      setContacts(data);
      setLoading(false);
    });
  }, [visible]);

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <Pressable style={styles.backdrop} onPress={onClose}>
        <Pressable style={[styles.sheet, { paddingBottom: insets.bottom + space.md }]} onPress={() => {}}>
          <View style={styles.grabber} />
          <Text style={styles.title}>New Call</Text>
          {loading ? (
            <View style={{ maxHeight: 420, paddingTop: space.xs }}>
              <SkeletonList count={4} />
            </View>
          ) : (
            <FlatList
              data={contacts}
              keyExtractor={(c) => c.id}
              style={{ maxHeight: 420 }}
              renderItem={({ item }) => (
                <View style={styles.row}>
                  <View style={[styles.avatar, { backgroundColor: item.avatarColor || hashColor(item.id) }]}>
                    <Text style={styles.avatarText}>{initials(item.name)}</Text>
                  </View>
                  <Text style={styles.name} numberOfLines={1}>{item.name}</Text>
                  <View style={styles.actions}>
                    <Pressable
                      hitSlop={8}
                      style={styles.iconBtn}
                      onPress={() => { hapticTap(); onClose?.(); onCall?.(item, 'voice'); }}
                    >
                      <Ionicons name="call" size={18} color={colors.accent} />
                    </Pressable>
                    <Pressable
                      hitSlop={8}
                      style={styles.iconBtn}
                      onPress={() => { hapticTap(); onClose?.(); onCall?.(item, 'video'); }}
                    >
                      <Ionicons name="videocam" size={19} color={colors.accent} />
                    </Pressable>
                  </View>
                </View>
              )}
              ListEmptyComponent={<Text style={styles.empty}>No contacts to call yet.</Text>}
            />
          )}
        </Pressable>
      </Pressable>
    </Modal>
  );
}

function getStyles(colors) {
  return StyleSheet.create({
    backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)', justifyContent: 'flex-end' },
    sheet: { backgroundColor: colors.surface, borderTopLeftRadius: radius.xl, borderTopRightRadius: radius.xl, paddingTop: space.sm },
    grabber: { width: 36, height: 4, borderRadius: 2, backgroundColor: colors.border, alignSelf: 'center', marginBottom: space.sm },
    title: { ...type.h1, fontSize: 16, color: colors.textPrimary, textAlign: 'center', marginBottom: space.sm },
    row: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: space.lg, paddingVertical: space.sm, gap: space.md },
    avatar: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
    avatarText: { color: '#F2F4F6', fontSize: 15, fontWeight: '600' },
    name: { ...type.body, color: colors.textPrimary, flex: 1, fontWeight: '500' },
    actions: { flexDirection: 'row', gap: space.md },
    iconBtn: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.surfaceRaised },
    empty: { ...type.body, color: colors.textMuted, textAlign: 'center', paddingVertical: space.xl },
  });
}
