// legalCopy.js
//
// App-identity constants and placeholder legal copy shared by the
// Settings > About screens, so they all show the exact same Terms/Privacy
// text instead of copies drifting apart. Swap the placeholder bodies for
// the real agreements before launch — the screens that render them don't
// need to change.

export const APP_NAME = 'Botmanager';
export const APP_VERSION = '1.0.0';
export const BUILD_NUMBER = '100';
export const SUPPORT_EMAIL = 'support@botmanager.app';

export const ABOUT_BODY =
  'Botmanager is a standalone bot management platform — create bots, issue their tokens, and ' +
  'route high-throughput messaging through your own account, all from one app. It is not built ' +
  'on top of any other messaging platform.\n\n' +
  'An account-level API key lets an agent or script create and manage bots on your behalf, while ' +
  'each bot gets its own token, the same way a BotFather-style token works.';

export const TERMS_BODY =
  'Placeholder terms of service. Replace this with the real agreement before launch — using ' +
  'Botmanager means you agree to keep your API keys secret, use the platform within its rate ' +
  'limits, and take responsibility for what your bots do on your behalf.';

export const PRIVACY_BODY =
  'Placeholder privacy policy. Replace this with the real policy before launch — describe what ' +
  'account and usage data is collected, how bot activity is logged, and how someone can request ' +
  'their data be deleted.';
