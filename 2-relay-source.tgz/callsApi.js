// callsApi.js — REAL call log, backed by the Worker's /calls endpoints.
// The only thing that's still simulated is the ringing timer in
// placeCall() — there's no WebRTC/telephony signaling server in this
// project, so "placing a call" can't be made real without one; the log
// entry it produces (via recordCall) is real and persisted.

import { api } from './api';
import { fetchConversations } from './messagesApi';

export const CALL_FILTERS = [
  { key: 'recent', label: 'Recent' },
  { key: 'missed', label: 'Missed' },
  { key: 'incoming', label: 'Incoming' },
  { key: 'outgoing', label: 'Outgoing' },
];

async function fetchAllCalls() {
  const calls = await api.listCalls();
  const convs = await fetchCallableContacts();
  const byId = Object.fromEntries(convs.map((c) => [c.id, c]));
  return (calls ?? []).map((call) => ({ ...call, contact: byId[call.contactId] ?? null }));
}

export async function fetchCalls(filter = 'recent') {
  try {
    const calls = await fetchAllCalls();
    if (filter === 'missed') return calls.filter((c) => c.status === 'missed');
    if (filter === 'incoming') return calls.filter((c) => c.direction === 'incoming');
    if (filter === 'outgoing') return calls.filter((c) => c.direction === 'outgoing');
    return calls;
  } catch {
    return [];
  }
}

// Alias used by some screens
export { fetchCalls as fetchCallLog };

export async function fetchCallsForContact(contactId) {
  const calls = await fetchAllCalls();
  return calls.filter((c) => c.contactId === contactId);
}

export async function fetchCallableContacts() {
  try {
    const convs = await fetchConversations();
    return (convs ?? []).filter((c) => c.kind === 'direct' || c.kind === 'bot');
  } catch {
    return [];
  }
}

export async function randomCallableContact() {
  const contacts = await fetchCallableContacts();
  if (!contacts.length) return null;
  return contacts[Math.floor(Math.random() * contacts.length)];
}

export async function logCall({ contactId, direction, type, status, durationSec }) {
  return api.logCall({ contactId, direction, type, status, durationSec });
}

// Alias used by the call screens
export async function recordCall(entry) {
  return logCall(entry);
}

// Simulated ringing → connect timer. There's no signaling backend to ring
// a real device against, so this drives the in-call UI's state machine
// on a timer instead. Returns a cancel function.
export function placeCall(contactId, type, { onConnected, ringMs = 2200 } = {}) {
  const timeout = setTimeout(() => {
    onConnected?.();
  }, ringMs);
  return () => clearTimeout(timeout);
}

export async function deleteCall(id) {
  await api.deleteCall(id);
}

// Alias used by some screens
export { deleteCall as deleteCallEntry };

export async function deleteCalls(ids) {
  await Promise.all(ids.map((id) => api.deleteCall(id)));
}

export async function clearHistory(filter = 'recent') {
  const calls = await fetchCalls(filter);
  await Promise.all(calls.map((c) => api.deleteCall(c.id)));
}

export async function clearContactHistory(contactId) {
  const calls = await fetchCallsForContact(contactId);
  await Promise.all(calls.map((c) => api.deleteCall(c.id)));
}
