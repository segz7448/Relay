# Botmanager — app (frontend)

Expo Router app, source only (not built/compiled).

## Structure
```
app/
  _layout.jsx            session gate (redirects to /auth if signed out) + notifications provider
  auth.jsx                create account
  auth-with-key.jsx        sign in with an existing API key
  (tabs)/
    _layout.jsx            bottom tabs: Bots · Notifications · Settings
    index.jsx              dashboard: live throughput, searchable bot list, pull-to-refresh
    notifications.jsx       permission prompt + in-app notification feed
    settings.jsx            account email, API key + rotation, sign out
  create-bot.jsx            register a bot, one-time token reveal
  bot/[id]/
    index.jsx               live rate, token rotation, delete (with confirm)
    edit.jsx                 rename, change webhook, toggle per-bot notifications
    activity.jsx             live-style message log (still placeholder data)
components/
  StatusPill / ThroughputMeter / BotRow / Button / Field
theme.js                    design tokens (control-room dark palette)
api.js                      fetch client for the control-plane server
auth.js                     persists the account API key in SecureStore across restarts
notifications.js             expo-notifications wrapper + in-app notification list (React Context)
```

## What's fully wired end-to-end
Sign up → session persists → list/search/create/edit/delete bots → rotate account
key or bot tokens (one-time reveal, same pattern for both) → enable push
notifications (registers the device's raw FCM push token with the account).

## Calling (Telegram/iOS-style)
- `call/[contactId]/incoming.jsx` — full-screen incoming-call UI: caller
  avatar with an expanding-ring "calling" animation, name, Accept /
  Decline / Message instead. Message instead opens a canned-reply sheet
  and hands off to the conversation with the text pre-filled (not
  auto-sent).
- `call/[contactId]/index.jsx` — the active call screen. For outgoing
  calls it drives its own ring→connect simulation; reached from
  `incoming.jsx` after Accept, it's connected immediately instead.
  Voice calls show the full iOS in-call grid — Mute, Speaker, Bluetooth,
  Keypad, Add participant, Hold — plus End call; video calls keep the
  simpler Mute/Camera/Keypad set.
- No push/signaling backend exists, so there's no real way for a call to
  "arrive." Long-press the **+** on the Calls tab to simulate one — it
  picks a random callable contact and opens the incoming-call screen.

## What's still a stub, on purpose
- `bot/[id]/activity.jsx` shows static sample events — needs a websocket/SSE
  tail of the server's message queue to go live.
- The in-app notification list only fills up from *locally received* push
  notifications — nothing server-side is sending them yet. `notifications.js`
  registers the device's push token with the account
  (`POST /accounts/me/push-token`), but no dispatcher calls `sendFCMToTokens`
  (see `worker/src/lib/fcm.ts`) when a bot actually gets a message. That's
  the next real backend piece.
- `server/` is a minimal reference implementation (in-memory store) — you're
  building the real backend, so treat routes/shapes here as the contract the
  frontend expects, not a deployment target.

## Running it
This wasn't built/compiled per your instructions — to actually run it:
```
npm install
npx expo start
```
Set `API_URL` in `config.js` to your deployed Cloudflare Worker URL.
For local dev with wrangler: use `http://10.0.2.2:8787` (Android emulator).

## Configuration and deployment

No credential belongs in this repository. Store `CLOUDFLARE_API_TOKEN`,
`CLOUDFLARE_ACCOUNT_ID`, `JWT_SECRET`, and `FCM_SERVER_KEY` as GitHub Actions
secrets. Store the public Worker base URL as the `API_URL` repository variable
and expose it to the Expo build as `EXPO_PUBLIC_API_URL`.

The checked-in CI workflow installs both lockfiles, type-checks and tests the
real Cloudflare Workers runtime against Miniflare D1/KV bindings, performs a
Worker dry-run build, and exports the Expo web app. Production deployment is
intentionally not guessed: create the named D1, KV, and R2 resources in
`worker/wrangler.toml`, then set their real binding IDs and secrets before
running `npm run deploy` in `worker/`.
